<!doctype html>
<html class="no-js" lang="">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title></title>
  <link rel="stylesheet" href="css/style.css">
  <meta name="description" content="">

  <meta property="og:title" content="">
  <meta property="og:type" content="">
  <meta property="og:url" content="">
  <meta property="og:image" content="">
  <meta property="og:image:alt" content="">

  <link rel="icon" href="/favicon.ico" sizes="any">
  <link rel="icon" href="/icon.svg" type="image/svg+xml">
  <link rel="apple-touch-icon" href="icon.png">

  <link rel="manifest" href="site.webmanifest">
  <meta name="theme-color" content="#fafafa">
</head>

<body>

<!-- Add your site or application content here -->
<p>Hello world! This is HTML5 Boilerplate.</p>
<script src="js/app.js"></script>

<form id="submit_form" method="post" class="form_reg" action="/php/scripts/reg_script.php">
  <label for="input_surname">Фамилия</label>
  <input id="input_surname" name="surname" type="text" required placeholder="Фамилия">

  <label for="input_name">Имя</label>
  <input id="input_name" name="name" type="text" required placeholder="Имя">

  <label for="input_last_name">Отчество</label>
  <input id="input_last_name" name="last_name" type="text" placeholder="Отчество">

  <label for="input_birthdate">Дата рождения</label>
  <input id="input_birthdate" name="birthdate" type="date" required placeholder="Дата рождения" onchange="{
    const fullYears = Math.floor((Date.now() - new Date(document.querySelector('#input_birthdate').value).getTime()) / (365.25 * 24 * 60 * 60 * 1000));
    document.querySelector('#show_age').innerText = `Полных лет: ${fullYears}`
  } ">

  <span id="show_age"></span>

  <label for="input_phone">Номер телефона</label>
  <input id="input_phone" name="phone" type="tel" pattern="+[0-9999]{1} [0-9]{3}-[0-9]{3}-[0-9]{4}" required
         placeholder="+7 123-456-8901">

  <label for="input_email">Электронная почта</label>
  <input id="input_email" name="email" type="email" required placeholder="Электронная почта">

  <label for="input_gender">Пол</label>
  <select id="input_gender" name="gender">
    <option value="not specified" selected>Не указан</option>
    <option value="male">Мужской</option>
    <option value="female">Женский</option>
  </select>

  <label for="input_education">Образование
    <input id="input_education" name="education" type="checkbox">
  </label>


  <label for="input_country">Страна</label>
  <select id="input_country" name="country">
    <option value="russia">Россия</option>
    <option value="belarus">Беларусь</option>
    <option value="kazakhstan">Казахстан</option>
    <option value="armenia">Армения</option>
    <option value="tadjikistan">Таджикистан</option>
  </select>
  <!--  <input id="input_surname" name="surname" type="text" required placeholder="Страна">-->

  <label for="input_pdata">Я согласен с обработкой моих персональных данных.
    <input id="input_pdata" name="personal_data" type="checkbox" required>
  </label>


  <input type="submit" value="Зарегистрироваться" name="doGo"></input>


</form>

</body>

</html>
